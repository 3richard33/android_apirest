package com.example.android.localapi;

/**
 * Created by synopsis on 23/01/18.
 */

public class Event {

    public final String apellidos;
    public final String nombres;
    public final String dnis;


    public Event(String eventApellidos, String eventNombre, String eventiD) {
        apellidos = eventApellidos;
        nombres = eventNombre;
        dnis = eventiD;
    }

}
